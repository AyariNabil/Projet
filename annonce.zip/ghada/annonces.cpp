#include "annonces.h"

annonces::annonces()
{
    identifiant=0;
    prix=0;
    billet=0;
    sejour="";
    date="";
}

annonces::annonces(int identifiant,int prix,int billet,QString sejour,QString date)
{
  this->identifiant=identifiant;
  this->prix=prix;
    this->billet=billet;
    this->sejour=sejour;
    this->date=date;
}

int annonces::get_identifiant(){return  identifiant;}
int annonces::get_prix(){return prix;}
int annonces::get_billet(){return  billet;}
QString annonces::get_sejour(){return  sejour;}
QString annonces::get_date(){return  date;}

bool annonces::ajouter()
{
QSqlQuery query;
QString res= QString::number(identifiant);
query.prepare("INSERT INTO annonce (IDENTIFIANT, PRIX, BILLET, SEJOUR, DATEE) "
                    "VALUES (:identifiant, :prix, :billet, :sejour, :date)");
query.bindValue(":identifiant", res);
query.bindValue(":prix", prix);
query.bindValue(":billet", billet);
query.bindValue(":sejour", sejour);
query.bindValue(":date", date);

return    query.exec();
}

bool annonces::modifier(int idd)
{
QSqlQuery query;
QString res= QString::number(idd);
query.prepare("UPDATE annonce SET PRIX=:prix, BILLET=:billet, SEJOUR=:sejour, DATEE=:date  WHERE identifiant=:identifiant");
query.bindValue(":identifiant", res);
query.bindValue(":prix", prix);
query.bindValue(":billet", billet);
query.bindValue(":sejour", sejour);
query.bindValue(":date", date);

return    query.exec();
}

QSqlQueryModel * annonces::afficher()
{QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select * from annonce order by IDENTIFIANT ");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("Numero des annonces"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("Séjour"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("Date"));
model->setHeaderData(3, Qt::Horizontal, QObject::tr("Numero du billet"));
model->setHeaderData(4, Qt::Horizontal, QObject::tr("Prix"));
    return model;
}

bool annonces::supprimer(int idd)
{
QSqlQuery query;
QString res= QString::number(idd);
query.prepare("Delete from annonce where IDENTIFIANT = :identifiant ");
query.bindValue(":identifiant", res);
return    query.exec();
}


