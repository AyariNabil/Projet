#include "billets.h"

billets::billets()
{
    identifiant=0;
    vol=0;
    bateau=0;
}

billets::billets(int identifiant,int vol,int bateau)
{
  this->identifiant=identifiant;
  this->vol=vol;
  this->bateau=bateau;
}

int billets::get_identifiant(){return  identifiant;}
int billets::get_vol(){return vol;}
int billets::get_bateau(){return  bateau;}

bool billets::ajouter()
{
QSqlQuery query;
QString res= QString::number(identifiant);
query.prepare("INSERT INTO billet (IDENTIFIANT, VOL, BATEAU) "
                    "VALUES (:identifiant, :vol, :bateau)");
query.bindValue(":identifiant", res);
query.bindValue(":vol", vol);
query.bindValue(":bateau", bateau);

return    query.exec();
}

bool billets::modifier(int idd)
{
QSqlQuery query;
QString res= QString::number(idd);
query.prepare("UPDATE billet SET VOL=:vol, BATEAU=:bateau WHERE identifiant=:identifiant");
query.bindValue(":identifiant", res);
query.bindValue(":vol", vol);
query.bindValue(":bateau", bateau);

return    query.exec();
}

QSqlQueryModel * billets::afficher()
{QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select * from billet order by IDENTIFIANT");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("Numero des billets"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("Numero du vol"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("Numero du bateau"));
    return model;
}

bool billets::supprimer(int idd)
{
QSqlQuery query;
QString res= QString::number(idd);
query.prepare("Delete from billet where IDENTIFIANT = :identifiant ");
query.bindValue(":identifiant", res);
return    query.exec();
}

