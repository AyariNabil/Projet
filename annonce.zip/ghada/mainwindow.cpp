#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "billets.h"
#include "annonces.h"
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
    ui->AfficherBillet_2->setModel(tmpbillets.afficher());
    ui->AfficherAnnonce->setModel(tmpannonces.afficher());
}


void MainWindow::on_AjoutBillet_clicked()
{
    int vol = ui->volAjout->text().toInt();
    int identifiant = ui->idBilletAjout->text().toInt();
    int bateau= ui->bateAjout->text().toInt();
  billets b(identifiant,vol,bateau);
  bool test=b.ajouter();
  if(test)
{ui->AfficherBillet_2->setModel(tmpbillets.afficher());//refresh
QMessageBox::information(nullptr, QObject::tr("Ajouter un Billet"),
                  QObject::tr("Billet ajouté.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);

}
  else
      QMessageBox::critical(nullptr, QObject::tr("Ajouter un billet"),
                  QObject::tr("Erreur !.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);

}

void MainWindow::on_ModifBillet_clicked()
{
    int vol = ui->volModif->text().toInt();
    int identifiant = ui->idBilletModif->text().toInt();
    int bateau= ui->bateauModif->text().toInt();
  billets b(identifiant,vol,bateau);
  bool test=b.modifier(identifiant);
  if(test)
{ui->AfficherBillet_2->setModel(tmpbillets.afficher());//refresh
QMessageBox::information(nullptr, QObject::tr("Modifier un Billet"),
                  QObject::tr("modifié ajouté.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);

}
  else
      QMessageBox::critical(nullptr, QObject::tr("Modifier un billet"),
                  QObject::tr("Erreur !.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);

}

void MainWindow::on_SuppBillet_clicked()
{
    int identifiant = ui->idBilletSupp->text().toInt();
    bool test=tmpbillets.supprimer(identifiant);
    if(test)
    {
        ui->AfficherBillet_2->setModel(tmpbillets.afficher());//refresh
        QMessageBox::information(nullptr, QObject::tr("Supprimer un Billet"),
                    QObject::tr("Billet supprimé.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else
        QMessageBox::critical(nullptr, QObject::tr("Supprimer un Billet"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

}

void MainWindow::on_AjoutAnnonce_clicked()
{
    int identifiant = ui->idAnnonceAjout->text().toInt();
    int prix = ui->Prixajout->text().toInt();
    int billet = ui->billetAjout->text().toInt();
    QString sejour= ui->sejourAjout->text();
    QString date= ui->dateAjout->text();
  annonces a(identifiant,prix,billet,sejour,date);
  bool test=a.ajouter();
  if(test)
{ui->AfficherAnnonce->setModel(tmpannonces.afficher());//refresh
QMessageBox::information(nullptr, QObject::tr("Ajouter un annonce"),
                  QObject::tr("Annonce ajouté.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);

}
  else
      QMessageBox::critical(nullptr, QObject::tr("Ajouter un annonce"),
                  QObject::tr("Erreur !.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);

}

void MainWindow::on_ModifAnnonce_clicked()
{
    int identifiant = ui->idAnnonceModif->text().toInt();
    int prix = ui->PrixModif->text().toInt();
    int billet = ui->BilletModif->text().toInt();
    QString sejour= ui->sejourModif->text();
    QString date= ui->DateModif->text();
  annonces a(identifiant,prix,billet,sejour,date);
  bool test=a.modifier(identifiant);
  if(test)
{ui->AfficherAnnonce->setModel(tmpannonces.afficher());//refresh
QMessageBox::information(nullptr, QObject::tr("Modifier un annonce"),
                  QObject::tr("Annonce modifié.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);

}
  else
      QMessageBox::critical(nullptr, QObject::tr("Modifier un annonce"),
                  QObject::tr("Erreur !.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);

}

void MainWindow::on_SuppAnnonce_clicked()
{
    int identifiant = ui->idAnnonceSupp->text().toInt();
    bool test=tmpannonces.supprimer(identifiant);
    if(test)
    {
        ui->AfficherAnnonce->setModel(tmpannonces.afficher());//refresh
        QMessageBox::information(nullptr, QObject::tr("Supprimer un annonce"),
                    QObject::tr("annonce supprimé.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else
        QMessageBox::critical(nullptr, QObject::tr("Supprimer un annonce"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

}
